# Project 3: Around The U.S.

### Overview

- Intro
- Figma
- Images

**Intro**

This project is made so all the elements are displayed correctly on popular screen sizes. We recommend investing more time in completing this project, since it's more difficult than previous ones.

**Figma**

- [Link to the project on [Github](https://justjordananderson.github.io/se_project_around_theus-main/)

**Images**

The way you'll do this at work is by exporting images directly from Figma — we recommend doing that to practice more. Don't forget to optimize them [here](https://tinypng.com/), so your project loads faster.

**Images Examples**

![Alt text](src/images/Sprint%203_%20Around%20the%20US.png)
![Alt text](src/images/project01.png)

Good luck and have fun!

link to video:
